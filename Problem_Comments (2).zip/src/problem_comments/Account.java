/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package problem_comments;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Account {

    private UUID id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private ArrayList<Problem> problems;

    public Account(String firstName, String lastName, String email, String password, ArrayList<Problem> problems) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.problems = problems;
        this.id = UUID.randomUUID();
    }

    public Account(String firstName, String lastName, String email, String password) {
        this(firstName, lastName, email, password, null);
    }

    public Account() {
    }

    public UUID getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<Problem> getProblems() {
        return problems;
    }

    public void setProblems(ArrayList<Problem> problems) {
        this.problems = problems;
    }

    private static List<Account> loadAccountsFromFile() {
        Gson gson = new Gson();
        List<Account> accounts = new ArrayList<>();

        try ( Reader reader = new FileReader("data.json")) {
            Type type = new TypeToken<List<Account>>() {
            }.getType();
            accounts = gson.fromJson(reader, type);
            if (accounts == null) {
                accounts = new ArrayList<>();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return accounts;
    }

    private static void saveAccountsToFile(List<Account> accounts) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try ( Writer writer = new FileWriter("data.json")) {
            gson.toJson(accounts, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void storeAccount(Account account) {
        List<Account> accounts = loadAccountsFromFile();
        accounts.add(account);
        saveAccountsToFile(accounts);
    }

    public static String getUserNameById(String accountId) {
        List<Account> accounts = loadAccountsFromFile();

        for (Account account : accounts) {
            if (account.getId().toString().equals(accountId)) {
                return account.getFirstName() + " " + account.getLastName();
            }
        }

        return null;
    }

}
