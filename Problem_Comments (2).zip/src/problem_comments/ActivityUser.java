
package problem_comments;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class ActivityUser {
    
    String user_id;
    String problem_id;
    boolean like;

    public ActivityUser(String user_id, String problem_id) {
        this.user_id = user_id;
        this.problem_id = problem_id;
        this.like = true;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getProblem_id() {
        return problem_id;
    }

    public boolean isLike() {
        return like;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public void setProblem_id(String problem_id) {
        this.problem_id = problem_id;
    }

    public void setLike(boolean like) {
        this.like = like;
    }
    
      public static void saveActivityUserToJson(ActivityUser activityUser) {
        List<ActivityUser> existingActivityUsers = getAllActivityUsersFromJson();

        if (existingActivityUsers == null) {
            existingActivityUsers = new ArrayList<>();
        }

        existingActivityUsers.add(activityUser);

        try (Writer writer = new FileWriter("activity.json")) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(existingActivityUsers, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<ActivityUser> getAllActivityUsersFromJson() {
        try (BufferedReader reader = new BufferedReader(new FileReader("activity.json"))) {
            Gson gson = new Gson();
            Type activityUserListType = new TypeToken<List<ActivityUser>>() {}.getType();
            return gson.fromJson(reader, activityUserListType);
        } catch (FileNotFoundException e) {
            // The activity file doesn't exist yet, return an empty list
            return new ArrayList<>();
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    
}
