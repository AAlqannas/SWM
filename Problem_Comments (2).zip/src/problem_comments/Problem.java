package problem_comments;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Problem {

    private String title;
    private String description;
    private List<Comment> comments;
    private int like = 0;
    private String imagePath;
    private UUID user_id;
    private UUID id;
    private Date publishTime;
    private long commentDurationMillis = 24 * 60 * 60 * 1000; //defult value after 24 hours stop comments on this problem;

    public Problem(String title, String description, String image, UUID user_id) {
        this.title = title;
        this.description = description;
        this.comments = new ArrayList<>();
        this.imagePath = image;
        this.id = UUID.randomUUID();
        this.user_id = user_id;

    }

    public void setLike(int like) {
        this.like = like;
    }

  

    public int getLike() {
        return like;
    }

  

    public void setCommentDurationMillis(long commentDurationMillis) {
        this.commentDurationMillis = commentDurationMillis;
    }

    public String getImagePath() {
        return imagePath;
    }

    public UUID getUser_id() {
        return user_id;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public long getCommentDurationMillis() {
        return commentDurationMillis;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public void setUser_id(UUID user_id) {
        this.user_id = user_id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public Problem() {

    }

    public UUID getId() {
        return id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public void setImage(String image) {
        this.imagePath = image;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public String getImage() {
        return imagePath;
    }

    public static List<Problem> getAllProblemsFromJSON(String filePath) {
        List<Problem> problems = new ArrayList<>();

        try ( BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonContent = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonContent.append(line);
            }

            Type listType = new TypeToken<List<Problem>>() {
            }.getType();
            problems = new Gson().fromJson(jsonContent.toString(), listType);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return problems;
    }

    public boolean canComment() {
        long elapsedTimeMillis = System.currentTimeMillis() - publishTime.getTime();
        return elapsedTimeMillis < commentDurationMillis;
    }

}
