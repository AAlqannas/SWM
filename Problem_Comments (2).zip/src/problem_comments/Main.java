package problem_comments;

public class Main {

    public static void main(String[] args) {
        reg r = new reg();
        r.setVisible(true);

    }

}
