package problem_comments;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class Comment {

    private String userId;
    private String comment;
    private String problemId;

    public Comment(String userId, String comment, String problemId) {
        this.userId = userId;
        this.comment = comment;
        this.problemId = problemId;
    }

    public Comment() {
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUserId() {
        return userId;
    }

    public String getComment() {
        return comment;
    }

    public String getProblemId() {
        return problemId;
    }

    public void setProblemId(String problemId) {
        this.problemId = problemId;
    }

    public static List<Comment> getAllCommentsByProblemId(String problemId) {
        List<Comment> matchingComments = new ArrayList<>();
        List<Comment> comments = getAllCommentsFromJSON();
        if (comments != null) {
            for (Comment comment : comments) {
                if (comment.getProblemId().equals(problemId)) {
                    matchingComments.add(comment);
                }
            }
        }

        return matchingComments;
    }

    public static List<Comment> getAllCommentsFromJSON() {
        List<Comment> comments = new ArrayList<>();

        try {
            File file = new File("comments.json");

            if (!file.exists()) {
                file.createNewFile();
            }

            try ( BufferedReader reader = new BufferedReader(new FileReader(file))) {
                Gson gson = new Gson();
                Type commentListType = new TypeToken<List<Comment>>() {
                }.getType();
                comments = gson.fromJson(reader, commentListType);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return comments;

    }

    public static void addCommentToJSON(Comment comment) {
        List<Comment> comments = getAllCommentsFromJSON();

        if (comments == null) {
            comments = new ArrayList<>();
        }

        comments.add(comment);

        writeCommentsToJSON(comments);
    }

    private static void writeCommentsToJSON(List<Comment> comments) {
        try ( Writer writer = new FileWriter("comments.json")) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(comments, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
