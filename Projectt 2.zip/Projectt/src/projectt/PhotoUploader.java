/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectt;

/**
 *
 * @author nina
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class PhotoUploader extends JFrame implements ActionListener {

    private JTextField filenameField;
    private JButton browseButton;
    private JTextArea descriptionArea;
    private JButton uploadButton;

    public PhotoUploader() {
        super("Photo Uploader");

        // Set the look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create the GUI components
        filenameField = new JTextField(20);
        browseButton = new JButton("Browse");
        descriptionArea = new JTextArea(5, 20);
        uploadButton = new JButton("Upload");

        // Set the layout
        setLayout(new BorderLayout());

        // Create the file chooser panel with labels
        JPanel fileChooserPanel = new JPanel(new FlowLayout(FlowLayout.LEADING, 10, 10));
        fileChooserPanel.add(new JLabel("Select a photo to upload:"));
        fileChooserPanel.add(filenameField);
        fileChooserPanel.add(browseButton);
        fileChooserPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        // Create the description panel with a titled border
        JPanel descriptionPanel = new JPanel(new BorderLayout());
        descriptionPanel.setBorder(BorderFactory.createTitledBorder("Description"));
        descriptionPanel.add(new JLabel("Enter a description for the photo:"), BorderLayout.NORTH);
        descriptionArea.setPreferredSize(new Dimension(200, 100)); // Set preferred size
        descriptionArea.setAlignmentX(LEFT_ALIGNMENT); // Align to the left
        descriptionPanel.add(new JScrollPane(descriptionArea), BorderLayout.CENTER);

        // Create the upload button panel with spacing and alignment
        JPanel uploadButtonPanel = new JPanel(new FlowLayout(FlowLayout.TRAILING, 10, 10));
        uploadButtonPanel.add(uploadButton);

        // Add the panels to the frame
        add(fileChooserPanel, BorderLayout.NORTH);
        add(descriptionPanel, BorderLayout.CENTER);
        add(uploadButtonPanel, BorderLayout.SOUTH);

        // Add the action listeners
        browseButton.addActionListener(this);
        uploadButton.addActionListener(this);

        // Set the default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the size of the frame
        setSize(400, 300);

        // Show the frame
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == browseButton) {
            // Handle the browse button click
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                filenameField.setText(selectedFile.getAbsolutePath());
            }
        } else if (e.getSource() == uploadButton) {
            // Handle the upload button click
            String filename = filenameField.getText();
            File file = new File(filename);
            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "The selected file does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String description = descriptionArea.getText();
            try {
                // Code to upload the file and store the description goes here
                JOptionPane.showMessageDialog(this, "The file has been uploaded successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "An error occurred while uploading the file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new PhotoUploader();
    }
}
