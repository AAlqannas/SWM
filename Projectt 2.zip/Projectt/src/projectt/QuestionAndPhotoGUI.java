
package projectt;

/**
 *
 * @author nina
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class QuestionAndPhotoGUI extends JFrame implements ActionListener {

    private JTextField questionTextField;
    private JButton postQuestionButton;
    private JTextField filenameField;
    private JButton browseButton;
    private JTextArea descriptionArea;
    private JButton uploadButton;

    public QuestionAndPhotoGUI() {
        super("Question and Photo");

        // Set the look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create the GUI components for question posting
        JPanel questionPanel = new JPanel(new FlowLayout());
        JLabel questionLabel = new JLabel("Enter your question:");
        questionTextField = new JTextField(20);
        postQuestionButton = new JButton("Post Question");

        questionPanel.add(questionLabel);
        questionPanel.add(questionTextField);
        questionPanel.add(postQuestionButton);

        // Create the GUI components for photo uploading
        JPanel fileChooserPanel = new JPanel(new FlowLayout(FlowLayout.LEADING, 10, 10));
        filenameField = new JTextField(20);
        browseButton = new JButton("Browse");

        fileChooserPanel.add(new JLabel("Select a photo to upload:"));
        fileChooserPanel.add(filenameField);
        fileChooserPanel.add(browseButton);

        JPanel descriptionPanel = new JPanel(new BorderLayout());
        descriptionPanel.setBorder(BorderFactory.createTitledBorder("Description"));
        descriptionArea = new JTextArea(5, 20);
        descriptionArea.setPreferredSize(new Dimension(200, 100));
        descriptionArea.setAlignmentX(LEFT_ALIGNMENT);
        descriptionPanel.add(new JScrollPane(descriptionArea), BorderLayout.CENTER);

        JPanel uploadButtonPanel = new JPanel(new FlowLayout(FlowLayout.TRAILING, 10, 10));
        uploadButton = new JButton("Upload");
        uploadButtonPanel.add(uploadButton);

        // Add action listeners
        postQuestionButton.addActionListener(this);
        browseButton.addActionListener(this);
        uploadButton.addActionListener(this);

        // Create the main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(questionPanel, BorderLayout.NORTH);
        mainPanel.add(fileChooserPanel, BorderLayout.CENTER);
        mainPanel.add(descriptionPanel, BorderLayout.SOUTH);

        // Set the layout for the frame
        setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);

        // Set the default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the size of the frame
        setSize(400, 400);

        // Show the frame
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == postQuestionButton) {
            String question = questionTextField.getText();
            if (!question.isEmpty()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("question", question);
                writeJSONToFile(jsonObject, "questions.json");

                JSONArray jsonArray = readJSONFromFile("questions.json");
                System.out.println("All questions read from JSON file:");
                if (jsonArray != null) {
                    for (Object obj : jsonArray) {
                        JSONObject jsonQuestion = (JSONObject) obj;
                        String questionFromJSON = (String) jsonQuestion.get("question");
                        System.out.println(questionFromJSON);
                    }
                }
            } else {
                System.out.println("Error: Question cannot be empty.");
            }
        } else if (e.getSource() == browseButton) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                filenameField.setText(selectedFile.getAbsolutePath());
            }
        } else if (e.getSource() == uploadButton) {
            String filename = filenameField.getText();
            File file = new File(filename);
            if (!file.exists()) {
                JOptionPane.showMessageDialog(this, "The selected file does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String description = descriptionArea.getText();
            try {
                // Code to upload the file and store the description goes here
                JOptionPane.showMessageDialog(this, "The file has been uploaded successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "An error occurred while uploading the file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void writeJSONToFile(JSONObject jsonObject, String filename) {
        JSONArray jsonArray;

        try (FileReader fileReader = new FileReader(filename)) {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(fileReader);

            if (obj instanceof JSONArray) {
                jsonArray = (JSONArray) obj;
            } else {
                jsonArray = new JSONArray();
            }
        } catch (IOException | ParseException e) {
            jsonArray = new JSONArray();
        }

        jsonArray.add(jsonObject);

        try (FileWriter fileWriter = new FileWriter(filename)) {
            fileWriter.write(jsonArray.toJSONString());
            System.out.println("JSON written to file: " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JSONArray readJSONFromFile(String filename) {
        try (FileReader fileReader = new FileReader(filename)) {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(fileReader);

            if (obj instanceof JSONArray) {
                return (JSONArray) obj;
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void main(String[] args) {
        new QuestionAndPhotoGUI();
    }
}
