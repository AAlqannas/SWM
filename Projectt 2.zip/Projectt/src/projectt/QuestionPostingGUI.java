
package projectt;

/**
 *
 * @author nina
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

public class QuestionPostingGUI extends JFrame implements ActionListener {

    private JTextField questionTextField;
    private JButton postButton;

    public QuestionPostingGUI() {
        setTitle("Question Posting");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout());

        JLabel questionLabel = new JLabel("Enter your question:");
        inputPanel.add(questionLabel);

        questionTextField = new JTextField(20);
        inputPanel.add(questionTextField);

        postButton = new JButton("Post");
        postButton.addActionListener(this);
        inputPanel.add(postButton);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        add(mainPanel);

        setVisible(true);
    }

    public static void main(String[] args) {
        QuestionPostingGUI gui = new QuestionPostingGUI();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == postButton) {
            String question = questionTextField.getText();
            if (!question.isEmpty()) {
                // Create a JSON object and set the question field
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("question", question);

                // Write the JSON object to the file
                writeJSONToFile(jsonObject, "questions.json");

                // Read the JSON objects from the file (optional)
                JSONArray jsonArray = readJSONFromFile("questions.json");
                System.out.println("All questions read from JSON file:");
                if (jsonArray != null) {
                    for (Object obj : jsonArray) {
                        JSONObject jsonQuestion = (JSONObject) obj;
                        String questionFromJSON = (String) jsonQuestion.get("question");
                        System.out.println(questionFromJSON);
                    }
                }
            } else {
                System.out.println("Error: Question cannot be empty.");
            }
        }
    }

    private void writeJSONToFile(JSONObject jsonObject, String filename) {
        JSONArray jsonArray;

        try (FileReader fileReader = new FileReader(filename)) {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(fileReader);

            if (obj instanceof JSONArray) {
                jsonArray = (JSONArray) obj;
            } else {
                jsonArray = new JSONArray();
            }
        } catch (IOException | ParseException e) {
            jsonArray = new JSONArray();
        }

        jsonArray.add(jsonObject);

        try (FileWriter fileWriter = new FileWriter(filename)) {
            fileWriter.write(jsonArray.toJSONString());
            System.out.println("JSON written to file: " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JSONArray readJSONFromFile(String filename) {
        try (FileReader fileReader = new FileReader(filename)) {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(fileReader);

            if (obj instanceof JSONArray) {
                return (JSONArray) obj;
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return null;
    }
}
